<?php

$api = "6740611620:AAHVwCBCVte-tkW5OpcobZhaA_-AT1fC_oQ";
$chatid = "6070538200";

?>
